Matrix = [[0 for x in range(6)] for y in range(7)] 
print(Matrix)

Matrix[0][0]=0

Matrix[1][0]=Matrix[0][0]+1
print(Matrix)
Matrix[2][0]=Matrix[1][0]+1
print(Matrix)
Matrix[3][0]=Matrix[2][0]+1
print(Matrix)
Matrix[4][0]=Matrix[3][0]+1
print(Matrix)
Matrix[5][0]=Matrix[4][0]+1
print(Matrix)
Matrix[6][0]=Matrix[5][0]+1
print(Matrix)
